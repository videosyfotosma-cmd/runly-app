const CACHE='runly-v1';
const ASSETS=['./','./index.html','./manifest.webmanifest','./assets/icon-192.png','./assets/icon-512.png','./assets/apple-touch-icon.png','./assets/runly-logo-black.png','./assets/runly-logo-white.png','./assets/splash.jpg','./assets/hero.jpg','./assets/run.jpg','./assets/community.jpg','./assets/people.jpg','./assets/moments.jpg','./assets/anywhere.jpg','./assets/newhere.jpg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
