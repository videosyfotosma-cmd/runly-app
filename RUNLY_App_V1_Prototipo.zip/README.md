# RUNLY V1 — Prototipo funcional para móvil

Esta carpeta contiene una **PWA funcional** de RUNLY, lista para probar en ordenador y posteriormente instalar en iPhone/Android cuando se publique en una URL con HTTPS.

## Qué incluye
- Splash de entrada con fotografía y logo RUNLY final.
- Pantalla **Inicio** con próxima quedada.
- Pantalla **Quedadas** con Thursday Run y Weekend Run abierto.
- Pantalla **Comunidad** con contenido visual provisional.
- Pantalla **Más** con perfil, ciudad, WhatsApp, email y privacidad.
- Registro local del usuario.
- Guardado de datos en `localStorage` (solo en el dispositivo).
- Manifest + Service Worker + iconos para instalación.

## Datos del administrador
- Email: `videosyfotosma@gmail.com`
- Teléfono / WhatsApp: `+34 636 408 047`

## Cómo probarlo en ordenador
Puedes abrir `index.html` directamente, o mejor servir la carpeta con un servidor local:

```bash
cd runly_app_v1
python3 -m http.server 8080
```

Luego abre:
- `http://localhost:8080/`

## Cómo instalarlo en iPhone
Cuando publiques esta carpeta en un hosting con **HTTPS**:
1. Abre la URL en **Safari**.
2. Pulsa **Compartir**.
3. Elige **Añadir a pantalla de inicio**.
4. Confirma **Añadir**.

## Estado actual
Esta V1 es un **prototipo visual y funcional**. Todavía no hay servidor ni base de datos. Los datos del registro se guardan localmente en el dispositivo hasta que decidamos la arquitectura final.
